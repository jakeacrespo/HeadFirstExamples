package headfirst.designpatterns.decorator.starbuzz.jake;

public class SteamMilk extends CondimentDecorator {
	Beverage beverage;

	public SteamMilk(Beverage beverage) {
		this.beverage = beverage;
	}

	@Override
	public String getDescription() {
		return beverage.getDescription() + ", Steam Milk";
	}

	@Override
	public double cost() {
		return .10 + beverage.cost();
	}

}
