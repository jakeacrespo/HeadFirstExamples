package headfirst.designpatterns.decorator.starbuzz.jake;

public abstract class CondimentDecorator extends Beverage {
	public abstract String getDescription();
}
