package headfirst.designpatterns.decorator.io.jake;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class InputTest {

	public static void main(String[] args) throws IOException {
		int c;
		String file = "C:\\jws\\HeadFirstExamples\\src\\main\\java\\headfirst\\designpatterns\\decorator\\io\\jake\\test.txt";
		try {
			InputStream in = 
				new LowerCaseInputStream(
					new BufferedInputStream(
						new FileInputStream(file)));

			while ((c = in.read()) >= 0) {
				System.out.print((char) c);
			}
			
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
