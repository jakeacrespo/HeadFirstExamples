package headfirst.designpatterns.strategy.design.puzzle.jake;

public class Queen extends Character {
	public Queen() {
		weaponBehavior = new BowAndArrow();
	}
	
	@Override
	void fight() {
		System.out.println("The " + name() + " attacks " + weaponBehavior.useWeapon());
	}

	@Override
	String name() {
		return "Queen";
	}
}
