package headfirst.designpatterns.strategy.design.puzzle.jake;

public class KingsBowlSimulator {

	public static void main(String[] args) {
		Character king = new King();
		king.fight();
		king.setWeapon(new BowAndArrow());
		king.fight();
		
		Character troll = new Troll();
		troll.fight();
		troll.setWeapon(new Knife());
		troll.fight();
		
		Character queen = new Queen();
		queen.fight();
		queen.setWeapon(new Axe());
		queen.fight();
		
		Character knight = new Knight();
		knight.fight();
		knight.setWeapon(new BowAndArrow());
		knight.fight();
	}

}
