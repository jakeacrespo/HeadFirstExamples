package headfirst.designpatterns.strategy.design.puzzle.jake;

public interface WeaponBehavior {
	public String useWeapon();
	
	public String name();
}
