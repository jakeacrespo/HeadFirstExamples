package headfirst.designpatterns.strategy.design.puzzle.jake;

public class Knight extends Character {
	public Knight() {
		weaponBehavior = new Sword();
	}

	@Override
	void fight() {
		System.out.println("The " + name() + " attacks " + weaponBehavior.useWeapon());
	}

	@Override
	String name() {
		return "Knight";
	}
}
