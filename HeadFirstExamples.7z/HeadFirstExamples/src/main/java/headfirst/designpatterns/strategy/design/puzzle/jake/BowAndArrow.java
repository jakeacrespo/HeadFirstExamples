package headfirst.designpatterns.strategy.design.puzzle.jake;

public class BowAndArrow implements WeaponBehavior {

	@Override
	public String useWeapon() {
		return "By shooting an Arrow to the knee with a Bow";
	}

	@Override
	public String name() {
		return "Bow and Arrow";
	}

}
