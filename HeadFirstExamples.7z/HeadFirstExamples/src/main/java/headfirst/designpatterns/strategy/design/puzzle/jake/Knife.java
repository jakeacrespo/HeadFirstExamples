package headfirst.designpatterns.strategy.design.puzzle.jake;

public class Knife implements WeaponBehavior {

	@Override
	public String useWeapon() {
		return "By cutting with a Knife";
	}

	@Override
	public String name() {
		return "Knife";
	}

}
