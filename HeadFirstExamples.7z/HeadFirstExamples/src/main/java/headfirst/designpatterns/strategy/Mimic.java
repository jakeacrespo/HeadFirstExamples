package headfirst.designpatterns.strategy;

public class Mimic implements QuackBehavior {

	@Override
	public void quack() {
		// TODO Auto-generated method stub
		System.out.println("Using: MIMIC Quack. It's super effective");
	}

}
