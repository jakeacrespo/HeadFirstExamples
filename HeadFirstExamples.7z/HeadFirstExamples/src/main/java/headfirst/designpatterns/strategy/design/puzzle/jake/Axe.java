package headfirst.designpatterns.strategy.design.puzzle.jake;

public class Axe implements WeaponBehavior {

	@Override
	public String useWeapon() {
		return "By chopping with an Axe";
	}

	@Override
	public String name() {
		return "Axe";
	}

}
