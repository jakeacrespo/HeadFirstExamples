package headfirst.designpatterns.strategy.design.puzzle.jake;

public abstract class Character {
	WeaponBehavior weaponBehavior;
	
	abstract void fight();
	
	abstract String name();
	
	public Character() {}
	
	public void setWeapon(WeaponBehavior wb) {
		System.err.println("Changing the "+ name() + "'s weapon to " + wb.name());
		this.weaponBehavior = wb;
	}

}
