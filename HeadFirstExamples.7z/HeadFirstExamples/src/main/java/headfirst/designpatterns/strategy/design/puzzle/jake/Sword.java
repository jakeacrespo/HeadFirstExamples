package headfirst.designpatterns.strategy.design.puzzle.jake;

public class Sword implements WeaponBehavior {

	@Override
	public String useWeapon() {
		return "By swingin a Sword";
	}

	@Override
	public String name() {
		return "Sword";
	}

}
