package headfirst.designpatterns.strategy.design.puzzle.jake;

public class Troll extends Character {
	public Troll() {
		weaponBehavior = new Axe();
	}

	@Override
	void fight() {
		System.out.println("The " + name() + " attacks " + weaponBehavior.useWeapon());
	}

	@Override
	String name() {
		return "Troll";
	}
}
