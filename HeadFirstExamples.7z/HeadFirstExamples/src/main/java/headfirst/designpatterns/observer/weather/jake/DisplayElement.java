package headfirst.designpatterns.observer.weather.jake;

public interface DisplayElement {
	public void display();
}
